const regions = [
  { name: "Hippocampus_REM", color: "pink", center: [10,10,10], size: 5 },
  { name: "Hippocampus_NREM", color: "lightpink", center: [10,10,10], size: 3 },
  { name: "Amygdala_REM", color: "lightblue", center: [15,12,8], size: 5 },
  { name: "Amygdala_NREM", color: "skyblue", center: [15,12,8], size: 3 },
  { name: "PFC_REM", color: "lightgreen", center: [12,18,15], size: 5 },
  { name: "PFC_NREM", color: "green", center: [12,18,15], size: 3 }
];

let traces = [];
regions.forEach(region => {
  const x=[], y=[], z=[];
  for(let i=-region.size;i<=region.size;i++){
    for(let j=-region.size;j<=region.size;j++){
      for(let k=-region.size;k<=region.size;k++){
        if(i*i+j*j+k*k <= region.size*region.size){
          x.push(region.center[0]+i);
          y.push(region.center[1]+j);
          z.push(region.center[2]+k);
        }
      }
    }
  }
  traces.push({
    type: 'scatter3d',
    mode: 'markers',
    x:x, y:y, z:z,
    marker: { size: 4, color: region.color },
    name: region.name
  });
});

const layout = {
  scene: { xaxis:{title:'X'}, yaxis:{title:'Y'}, zaxis:{title:'Z'} },
  title: 'Interactive REM/NREM Brain Activation'
};

Plotly.newPlot('brain-plot', traces, layout, {responsive:true});